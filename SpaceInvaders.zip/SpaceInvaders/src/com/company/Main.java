package com.company;

import java.awt.*;

public class Main extends GameEngine{
    boolean left, right;
    boolean gameOver;

    double playerX, playerY;
    double playerVX, playerVY;

    // Init variables
    Image backgroundImg;
    Image planet1;
    Image planet2;
    Image galaxy;
    Image playerIMG;
    Image enemyIMG;

    Image enemyImg;
    int screenW = 1000;
    int screenH = 600;

    public static void main(String[] args) {
        createGame(new Main());}
    public void loadImages(){
        backgroundImg = loadImage("src/space_background.png");
        Image planetSheet = loadImage("src/Planets.png");
        Image shipSheet = loadImage("src/SpaceShipAsset.png");
        planet1 = subImage(planetSheet, 0, 0, 64, 64);
        planet2 = subImage(planetSheet, 63,63, 64, 64);
        galaxy = subImage(planetSheet, 260, 100, 120, 120);
        playerIMG = subImage(shipSheet,0,0,10,10);
        enemyIMG = subImage(shipSheet, 10,60, 10, 10);
    }
    // Menu
    public void initMenu(){

    }
    public void updateMenu(){

    }
    public void drawMenu(){

    }
    // Player
    public void initPlayer(){

        playerX = screenW*0.5;
        playerY = screenH-50;

        playerVX = 0;
        playerVY = 20;


    }
    public void updatePlayer(double dt){
        playerX += playerVX*dt;
        playerY += playerVY*dt;
        if(playerX >= screenW || playerX >= 0){
            gameOver=true;
        }

    }
    public void drawPlayer(){

    }
    // Bullet
    public void initBullet(){

    }
    public void updateBullet(){

    }
    public void drawBullet(){

    }
    // Aliens
    public void initAliens(){

    }
    public void updateAliens(){

    }
    public void drawAliens() {

    }
        // Main game methods
    public void init(){
        loadImages();
        setWindowSize(screenW, screenH);
        gameOver = false;

        initMenu();
        initPlayer();
        initBullet();
        initAliens();
        if(gameOver){
            initMenu();
        }
    }
    @Override
    public void update(double dt) {
        if(gameOver){return;}

        updateMenu();
        updatePlayer(dt);
        updateBullet();
        updateAliens();
    }

    @Override
    public void paintComponent() {
        // Set up background
        changeBackgroundColor(black);
        drawImage(backgroundImg, 0, 0, screenW, screenH);
        drawImage(galaxy, screenW-175, 200, 300, 300);
        drawImage(planet1, 0, 0, 150, 150);
        drawImage(planet2, screenW-100,0, 100, 100);
        // Draws player/effects/aliens
        drawMenu();
        drawPlayer();
        drawBullet();
        drawAliens();

    }
}
